import sys
import os

Text_Start_Address = 0x00400000 # default base address for an exetutable 
Data_Start_Address = 0x00500000 # default .data initial address
Max_address = 0x00A00000        # max stack address
Memory = [0]*0x600000           # 1MB = 1024x1024 

Reg = {
    '00000': 0x00000000,
    '00001': 0x00000000,
    '00010': 0x00000000,
    '00011': 0x00000000,
    '00100': 0x00000000,
    '00101': 0x00000000,
    '00110': 0x00000000,
    '00111': 0x00000000,
    '01000': 0x00000000,
    '01001': 0x00000000,
    '01010': 0x00000000,
    '01011': 0x00000000,
    '01100': 0x00000000,
    '01101': 0x00000000,
    '01110': 0x00000000,
    '01111': 0x00000000,
    '10000': 0x00000000,
    '10001': 0x00000000,
    '10010': 0x00000000,
    '10011': 0x00000000,
    '10100': 0x00000000,
    '10101': 0x00000000,
    '10110': 0x00000000,
    '10111': 0x00000000,
    '11000': 0x00000000,
    '11001': 0x00000000,
    '11010': 0x00000000,
    '11011': 0x00000000,
    '11100': 0x00508000,
    '11101': 0x00A00000,
    '11110': 0x00A00000,
    '11111': 0x00000000,
    'pc': 0x00400000,
    'hi': 0x00000000,
    'lo': 0x00000000,

    'Virtual_DATA_ADDR': 0x00500000,
    'break': 0, 
    'input_idx': 0,                 
}

MIPS_Assembler_File = sys.argv[1]
BINARY_file = sys.argv[2]
CHECKPOINTS_file = sys.argv[3]
INPUT_file = sys.argv[4]
OUTPUT_file = sys.argv[5]

#change string to int
def Str_To_Int(Str):
    if '0x' in Str:
        return int(Str, 16)
    elif '0o' in Str:
        return int(Str, 8)
    elif '0b' in Str:
        return int(Str, 2)
    else:
        return int(Str)

def Dump_Mem(n):
    with open ('memory' + str(n) + '.bin', 'wb') as out:
        for i in range(0, len(Memory)):
            out.write(Memory[i].to_bytes(1, 'big'))

def Dump_Reg(n):
    with open ('register' + str(n) + '.bin', 'wb') as out:
        for i, j in enumerate(Reg.values()):
            out.write((j&0xFFFFFFFF).to_bytes(4, 'little'))
            if i == 34:
                break

def Iden_Data_Type(Data_List, Data_Addr):
    if Data_List[0] == '.ascii':
        Data_Addr += len(Data_List[1])
    elif Data_List[0] == '.asciiz':
        Data_Addr += len(Data_List[1]) + 1
    elif Data_List[0] == '.byte':
        Data_Addr += 1
    elif Data_List[0] == '.half':
        Data_Addr += 2
    elif Data_List[0] == '.word':
        Data_Addr += 4
    else:
        raise TypeError('The data type is not supported. ')
    return Data_Addr

with open(CHECKPOINTS_file,'r') as points_file:
    indexes = points_file.read().split()
    for i in range(len(indexes)):
        indexes[i] = Str_To_Int(indexes[i])

with open(INPUT_file, 'r') as in_txt:
    input_text = in_txt.read().split('\n')

with open(OUTPUT_file, 'w') as out:
    out.write('')

with open(MIPS_Assembler_File, 'r') as MIPS_file:
    fileLine = MIPS_file.readlines()
    i = 0
    while i < len(fileLine):                          # read each line                          
        fileLine[i] = fileLine[i].rstrip('\n')        # remove newline             
        fileLine[i] = fileLine[i].replace('\t', ' ')  # replace tab with space            
        fileLine[i] = fileLine[i].partition('#')      # search for the comments and split             
        fileLine[i] = fileLine[i][0]                  # remove comments if exiting              
        fileLine[i] = fileLine[i].partition(':')      # search for the label and split            
        fileLine[i] = [''.join(fileLine[i][:2]), fileLine[i][2]]
        i += 1
    # rearrange the testfile for convenience to read in phase2
    new_file = []
    for i in fileLine:                                 # extract list in old list(fileLine)
        for j in i:                                    # extract string in list
            new_file.append(j)                         # add the string to the new list
    for i in new_file:                                 # read the string one by one
        if i.isspace() == True:                        # to check whther the string is empty  
            new_file.remove(i)                         # remove it if empty
    new_file = [x for x in new_file if x != '']        # remove the string ''
    new_file = [x.strip() for x in new_file]           # remove the space at the beginning and
                                                       # end of the string
    Data_pos = new_file.index('.data')                 # .data index
    Text_pos = new_file.index('.text')                 # .text index

    Data_sec = []                                      # extract the data section 
    if Data_pos == 0:                                  # .data before .text section
        for i in range(1, Text_pos):                   
            Data_sec.append(new_file[i])             
    else:                                              # .data after .text section 
        for i in range(Data_pos, len(new_file)):      
            Data_sec.append(new_file[i]) 
           
    New_Data = []                                      # create list: [...,[type, data, address], ...]
    k = 0
    while k < len(Data_sec):
        if Data_sec[k].endswith(':') == False:                     # distinguish the label
            if '"' in Data_sec[k]:                     # distinguish strings in ascii, asciiz
                Data_sec[k] = Data_sec[k].split('"')

                for x in range(len(Data_sec[k])):
                    Data_sec[k][x] = eval('"%s"' % Data_sec[k][x]) # change \\s to \s
                # break down multiple declarations in one row, separated by ','
                # data[k]: ['.ascii', 'str', ',', str', ',',...], the odd index is what we want
                for y in range(len(Data_sec[k])):
                    if y % 2 != 0:
                        New_Data.append([Data_sec[k][0].strip(), Data_sec[k][y]])
            else:
                # byte, half, word
                Data_sec[k] = Data_sec[k].strip()
                Data_sec[k] = list(Data_sec[k].partition(' '))  # break down multiple declarations, sep by ',' .
                Data_sec[k][2] = Data_sec[k][2].split(',')
                for z in range(len(Data_sec[k][2])):
                    New_Data.append([Data_sec[k][0], Str_To_Int(Data_sec[k][2][z])])
        k += 1

    m = 0

    for i in range(len(New_Data)):
        if New_Data[i][0] in ['.ascii', '.asciiz', '.word']:
            if Reg['Virtual_DATA_ADDR'] % 4 == 1:
                Reg['Virtual_DATA_ADDR'] += 3
            elif Reg['Virtual_DATA_ADDR'] % 4 == 2:
                Reg['Virtual_DATA_ADDR'] += 2
            elif Reg['Virtual_DATA_ADDR'] % 4 == 3:
                Reg['Virtual_DATA_ADDR'] += 1
        elif New_Data[i][0] == '.half':
            if Reg['Virtual_DATA_ADDR'] % 2 == 1:
                Reg['Virtual_DATA_ADDR'] += 1
        New_Data[i].append(Reg['Virtual_DATA_ADDR'] - 0x00400000)
        Reg['Virtual_DATA_ADDR'] = Iden_Data_Type(New_Data[i], Reg['Virtual_DATA_ADDR'])

with open(BINARY_file, 'r') as Machine_Code:
    Code_List = Machine_Code.read().split()
    for i in range(len(Code_List)):
        Code_List[i] = [Code_List[i][24:32], Code_List[i][16:24], Code_List[i][8:16], Code_List[i][0:8]]
        for j in range(4):
            Code_List[i][j] = int(Code_List[i][j], 2)

    Text_Code = []
    for i in Code_List:                                 # extract list in old list(Code_List)
        for j in i:                                    # extract string in list
            Text_Code.append(j)                         # add the string to the new list

    
    for i in range(len(Text_Code)):
        Memory[i] = Text_Code[i]

def Init_Data_Addr(Data):
    if Data[0] == '.byte':
        Memory[Data[2]] = Data[1] & 0xFF
    elif Data[0] in ['.ascii', '.asciiz']:
        for j in range(len(Data[1])):
            Memory[Data[2]+j] = ord(Data[1][j])
    elif Data[0] == 'half':
        Memory[Data[2]] = int('{:#006x}'.format(Data[1] & 0xFFFF)[4:6], 16)
        Memory[Data[2]+1] = int('{:#006x}'.format(Data[1] & 0xFFFF)[0:4], 16)
    elif Data[0] == '.word':
        Memory[Data[2]] = int('{:#010x}'.format(Data[1]&0xFFFFFFFF)[8:10], 16)
        Memory[Data[2] + 1] = int('{:#010x}'.format(Data[1]&0xFFFFFFFF)[6:8], 16)
        Memory[Data[2] + 2] = int('{:#010x}'.format(Data[1]&0xFFFFFFFF)[4:6], 16)
        Memory[Data[2] + 3] = int('{:#010x}'.format(Data[1]&0xFFFFFFFF)[0:4], 16)
    return Memory

for i in range(len(New_Data)):
    Memory = Init_Data_Addr(New_Data[i])

def add(rd, rs, rt):
    Reg[rd] = Reg[rs] + Reg[rt] # put the sum of registers rs and rt into register rd

def addi(rt, rs, Imm):
    # The 16-bit signed Immediate is added to the 32-bit value in GPR rs to produce a 32-bit
    # result. If it doesn't overflow, the 32-bit result is placed into GPR rt
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    Reg[rt] = Reg[rs] + Imm_INT

def addiu(rt, rs, Imm):
    # similar as addi
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    Reg[rt] = int('{:#035b}'.format(Reg[rs] + Imm_INT)[3:], 2)  # take the lower 32 bits

def addu(rd, rs, rt):
    Reg[rd] = int('{:035b}'.format(Reg[rs] + Reg[rt])[3:], 2) # similar as add

def and_R(rd, rs, rt):  # R-Type and, since the word "and" is preserved, use and_R to represent "and" 
    Reg[rd] = Reg[rs] & Reg[rt] # put the logical AND of registers rs and rt into register rd

def andi(rt,rs, Imm):
    # Put the logical AND of register rs and the zero-extended Immediate into register rt
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    Reg[rt] = Reg[rs] & Imm_INT

def beq(rs, rt, Imm):
    #conditionally branch the number of instrctions specified by the offset if register rs == rt
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) - 1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] == Reg[rt]:
        # branch target address = pc + 4 + Immediate*4
        Reg['pc'] += Imm_INT*4

def bgez(rs, Imm):
    # Conditionally branch the number of instructions specified by the offset if register rs >= 0
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] >= 0:
        # branch target address = pc + 4 + Immediate*4
        Reg['pc'] += Imm_INT*4

def bgtz(rs, Imm):
    # Conditionally branch the number of instr specified by the offset if reg rs > 0
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] > 0:
         # branch target address = pc + 4 + Immediate*4
         Reg['pc'] += Imm_INT*4

def blez(rs, Imm):
    # Conditionally branch the number of instr specified by the offset if reg rs <= 0
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] <= 0:
        # branch target address = pc + 4 + Immediate*4
        Reg['pc'] += Imm_INT*4

def bltz(rs, Imm):
    # Conditionally branch the number of instr specified by the offset if reg rs < 0
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] < 0:
        # branch target address = pc + 4 + Immediate*4
        Reg['pc'] += Imm_INT*4

def bne(rs, rt, Imm):
    #conditionally branch the number of instrctions specified by the offset if register rs != rt
    if Imm.startswith('1'):
        Imm_INT = int(Imm, 2) - int('1'*len(Imm), 2) -1
    else:
        Imm_INT = int(Imm, 2)
    if Reg[rs] != Reg[rt]:
        # branch target address = pc + 4 + Immediate*4
        Reg['pc'] += Imm_INT*4

def div(rs, rt):
    Reg['lo'] = Reg[rs] // Reg[rt]    # Devide register rs by register, leave the quotient in lo
    Reg['hi'] = Reg[rs] % Reg[rt]     # leave the remainder in register hi

def divu(rs, rt):
    Reg['lo'] = (Reg[rs] // Reg[rt]) & 0xFFFFFFFF    # Devide register rs by register, leave the quotient in lo
    Reg['hi'] = (Reg[rs] % Reg[rt]) & 0xFFFFFFFF     # leave the remainder in register hi

def j(Imm):
    pc_Str = '{:#034b}'.format(Reg['pc'])[2:]
    jump_target_addr = pc_Str[0:4] + Imm + '00'
    Reg['pc'] = int(jump_target_addr, 2) - 4

def jal(Imm):
    pc_Str = '{:#034b}'.format(Reg['pc'])[2:]
    Reg['11111'] = Reg['pc'] + 4
    # jump_target_address = {(pc + 4)[31:28], Immediate, 2'b00}
    jump_target_addr = pc_Str[0:4] + Imm + '00'
    Reg['pc'] = int(jump_target_addr, 2) - 4

def jalr(rs):
    # Unconditionally jump to the instruction whose address is in register rs
    # Save the address of the next instruction in register rd (default to 31, $ra)
    Reg['11111'] = Reg['pc'] + 4
    Reg['pc'] = Reg[rs] - 4

def jr(rs):
    # Jump to the effective target address in rs. 
    # Execute the instruction following the jump, in the branch delay slot, before jumping
    Reg['pc'] = Reg[rs] - 4

def lb(rt, base, offset):
    # The contents of the 8-bit byte at the Memory location specified by the effective address
    # are fetched, sign-extended, and placed in rt. The 16-bit signed offset is added to the contents
    # of GPR base to form the effective address
    if offset.startswith('1'):
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)

    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    CONTENTS = Memory[DATA_ADDR - 0x00400000]
    CONTENTS_Str = '{:#010b}'.format(CONTENTS)[2:]
    if CONTENTS_Str[0] == '1':
        CONTENTS_Str += '1'*(32-len(CONTENTS_Str))
    EXTEND_CONTENTS = int(CONTENTS_Str, 2)
    Reg[rt] = EXTEND_CONTENTS 

def lbu(rt, base, offset):
    # The contents of the 8-bit byte at the Memory location specified by the effective address
    # are fetched, zero-extended, and placed in rt. The 16-bit signed offset is added to the contents
    # of GPR base to form the effective address
    if offset.startswith('1'):
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)

    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    CONTENTS = Memory[DATA_ADDR - 0x00400000]
    Reg[rt] = CONTENTS

def lh(rt, base, offset):
    # The contents of the 16-bit halfword at the Memory location specified by the aligned
    # effective address are fetched, sign-extended, and placed in GFR rt. The 16-bit
    # signed offset is added to the contents of GPR base to form the effective address
    if offset.startswith('1'):
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    CONTENTS_Str = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 1])[2:] + '{:#010b}'.format(Memory[DATA_ADDR - Text_Start_Address])[2:]

    if CONTENTS_Str.startswith('1'):
        CONTENTS_Str += '1'*(32-len(CONTENTS_Str))
    EXTEND_CONTENTS = int(CONTENTS_Str, 2)
    if CONTENTS_Str.startswith('1'):
        EXTEND_CONTENTS = - ((-EXTEND_CONTENTS)&0xFFFFFFFF)
    Reg[rt] = EXTEND_CONTENTS

def lhu(rt, base, offset):
    # The contents of the 16-bit halfword at the Memory location specified by the aligned effective
    # address are fetched, zero extended, and placed in GPR rt. The 16-bit signed offset is added to the 
    # contents of GPR base to form the effective address
    if offset[0] == '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    CONTENTS_Str = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 +1])[2:] + '{:#010b}'.format(Memory[DATA_ADDR - Text_Start_Address])[2:]
    Reg[rt] = int(CONTENTS_Str, 2)

def lui(rt, Imm):
    # The 16-bit Immediate is shifted left 16 bits and concatenated with 16 bits of low-order zeros
    # The 32-bit result is sign-extended and placed into GPR rt
    Reg[rt] = (int(Imm, 2) << 16)

def lw(rt, base, offset):
    if offset[0] ==  '1':
        offset+='1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)

    CONTENTS_Str = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000+3])[2:] + \
                   '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000+2])[2:]+ \
                   '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000+1])[2:] + \
                   '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000])[2:]
    if CONTENTS_Str[0] == '1':
        CONTENTS_Str += '1'*(32-len(CONTENTS_Str))
    EXTEND_CONTENTS = int(CONTENTS_Str, 2)
    if CONTENTS_Str[0] == '1':
        EXTEND_CONTENTS = - ((-EXTEND_CONTENTS)&0xFFFFFFFF)
    Reg[rt] = EXTEND_CONTENTS

def lwl(rt, base, offset):
    if offset[0] ==  '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR_str = '{:#035b}'.format( Reg[base] + EXTEND_offset )[3:]
    DATA_ADDR_aligned = DATA_ADDR_str[:30] + '00'
    DATA_ADDR = int(DATA_ADDR_aligned, 2)
    rt_str = '{:#034b}'.format((Reg[rt])&0xFFFFFFFF)[2:]

    if  DATA_ADDR_str.endswith('00'):
        rt_3 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000])[2:]
        rt_2 = rt_str[ 8:16]
        rt_1 = rt_str[16:24]
        rt_0 = rt_str[24:32]
    elif DATA_ADDR_str.endswith('01'):
        rt_3 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 1])[2:]
        rt_2 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000])[2:]
        rt_1 = rt_str[16:24]
        rt_0 = rt_str[24:32]
    elif DATA_ADDR_str.endswith('10'):
        rt_3 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 2])[2:]
        rt_2 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 1])[2:]
        rt_1 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000])[2:]
        rt_0 = rt_str[24:32]
    elif DATA_ADDR_str.endswith('11'):       
        rt_3 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 3])[2:]
        rt_2 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 2])[2:]
        rt_1 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000 + 1])[2:]
        rt_0 = '{:#010b}'.format(Memory[DATA_ADDR - 0x00400000])[2:]

    final_data = int(rt_3 + rt_2 + rt_1 + rt_0, 2)
    if rt_3.startswith('1'):
        final_data = -((-final_data)&0xFFFFFFFF)
    Reg[rt] = final_data

def lwr(rt, base, offset):
    if offset[0] ==  '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR_str = '{:#035b}'.format( Reg[base] + EXTEND_offset )[3:]
    DATA_ADDR_aligned = DATA_ADDR_str[:30] + '00'
    DATA_ADDR = int(DATA_ADDR_aligned, 2)
    rt_str = '{:#034b}'.format((Reg[rt])&0xFFFFFFFF)[2:]

    if DATA_ADDR_str.endswith('00'):
        rt_3 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 3 ])[2:]
        rt_2 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 2 ])[2:]
        rt_1 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 1 ])[2:]
        rt_0 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address])[2:]
    elif DATA_ADDR_str.endswith('01'):
        rt_3 = rt_str[0: 8]
        rt_2 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 3 ])[2:]
        rt_1 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 2 ])[2:]
        rt_0 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 1 ])[2:]
    elif DATA_ADDR_str.endswith('10'):
        rt_3 = rt_str[ 0: 8]
        rt_2 = rt_str[ 8:16]
        rt_1 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 3 ])[2:]
        rt_0 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 2 ])[2:]
    elif DATA_ADDR_str.endswith('11'):       
        rt_3 = rt_str[ 0: 8]
        rt_2 = rt_str[ 8:16]
        rt_1 = rt_str[16:24]
        rt_0 = '{:#010b}'.format(Memory[ DATA_ADDR - Text_Start_Address + 3 ])[2:]
    final_data = int(rt_3 + rt_2 + rt_1 + rt_0, 2)
    if rt_3.startswith('1'):
        final_data =  -((-final_data)&0xFFFFFFFF)
    Reg[rt] = final_data

def mfhi(rd):
    Reg[rd] = Reg['hi']    # The contents of special register HI are loaded into GPR rd

def mflo(rd):
    Reg[rd] = Reg['lo']    # The contents of special register LO are loaded into GPR rd

def mthi(rs):
    Reg['hi'] = Reg[rs]    # The contents of GPR rs are loaded into special register HI 

def mtlo(rs):
    Reg['lo'] = Reg[rs]    # The contents of GPR rs are loaded into special register LO

def mult(rs, rt):
    # (LO, HI) <-- rs x rt
    # The 32-bit word value in GPR rt is multiplied by the 32-bit value in GPR rs, treating both
    # operands as signed values, to produce a 64-bit result. The low-order 32-bit word of the result
    # is placed into special register LO, and the high-order 32-bit word is place into special register HI
    PRODUCT = Reg[rs] * Reg[rt]
    PRODUCT_Str = '{:#066b}'.format(PRODUCT)[2:]
    Reg['lo'] = int(PRODUCT_Str[32:64], 2)
    Reg['hi'] = int(PRODUCT_Str[0:32], 2)

def multu(rs, rt):
    # Same as above, but unsighned
    PRODUCT = (Reg[rs]&0xFFFFFFFF) * (Reg[rt]&0xFFFFFFFF)
    PRODUCT_Str = '{:#066b}'.format(PRODUCT)[2:]
    Reg['lo'] = int(PRODUCT_Str[32:64], 2)
    Reg['hi'] = int(PRODUCT_Str[0:32], 2)

def nor(rd, rs, rt):
    # The contents of GPR rs are combined with the contents of GPR rt in a bitwise logical NOR
    # operation. The result is placed into GPR rd
    Reg[rd] = ~(Reg[rs] | Reg[rt])

def or_R(rd, rs, rt):
    # The contents of GPR rs are combined with the contents of GPR rt in a bitwise logical OR
    # operation. The result is placed into GPR rd
    Reg[rd] = (Reg[rs] | Reg[rt])

def ori(rt, rs, Imm):
    # The 16-bit Immediate is 0 extended to the left and combined with the contents of GPR rs in
    # bitwise logical OR operation. The result is placed into GPR rt
    if Imm[0] == '1':
        ImmE_INT = int(Imm, 2) - int('1'*len(Imm), 2) - 1
    else:
        ImmE_INT = int(Imm, 2)
    Reg[rt] = Reg[rs] | ImmE_INT

def sb (rt, base, offset):
    if offset[0] ==  '1':
        offset+='1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    Memory[DATA_ADDR - Text_Start_Address ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)

def sh (rt, base, offset):
    if offset[0] ==  '1':
        offset+='1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    Memory[DATA_ADDR - Text_Start_Address] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
    Memory[DATA_ADDR - Text_Start_Address + 1 ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)

def sll(rd, rt, sa):
    # The contents of the low-order 32-bit word of GPR rt are shifted left, inserting zeroes into
    # the emptied bits; the word result is placed in GPR rd. The bit shift count is specified by sa
    #if rd is a 64-bit register, the result word is sigh-extended
    sa = int(sa, 2)
    Reg[rd] = int('{:035b}'.format(Reg[rt] << sa)[3:], 2)

def sllv(rd, rt, rs):
    # The cotents of the low-order 32-bit word of GPR rt are shifted left, inserting zeroes into
    # the emptied bits; the result word is placed in GPR rd. The bit shift count is specified
    # by the low-order five bits of GPR rs. If rd is a 64-bit register, the result word is sign-extended
    Reg[rd] = int('{:#035b}'.format(Reg[rt] << Reg[rs])[3:], 2)

def slt(rd, rs, rt):
    # Compare the contents of GPR rs and GPR rt as sighned integers and record the Boolean
    # result of the comparison in GPR rd. If GPR rs is less than GPR rt the result is 1; otherwise 0
    if Reg[rs] < Reg[rt]:
        Reg[rd] = 0x1
    else:
        Red[rd] = 0x0 

def slti(rt, rs, Imm):
    # Compare the contents of GPR rs and the 16-bit signed Immediate as signed integers
    # and record the Boolean result of the comparison in GPR rt. If GPR rs is less than 
    # Immediate the result is 1, otherwise 0.
    if Imm[0] == '1':
        ImmE_INT = int(Imm, 2) - int('1'*len(Imm), 2) - 1
    else:
        ImmE_INT = int(Imm, 2)
    if Reg[rs] < ImmE_INT:
        Reg[rt] = 0x1
    else:
        Reg[rt] = 0x0

def sltiu(rs, rt, Imm):
    # Compare the contents of GPR rs and the 16-bit signed Immediate as unsigned integers
    # and record the Boolean result of the comparison in GPR rt. If GPR rs is less than 
    # Immediate the result is 1, otherwise 0.
    if Imm[0] == '1':
        offset += '1'*(32-len(Imm))
    EXTEND_ImmE = int(Imm, 2)
    if (Reg[rs]&0xFFFFFFFF) < EXTEND_ImmE:
        Reg[rt] = 0x1
    else:
        Reg[rt] = 0x0

def sltu(rd, rs, rt):
    # Compare the contents of GPR rs and the sign-extended 16-bit Immediate as unsigned integers
    # and record the Boolean result of the comparison in GPR rt. If GPR rs < Imm, result = 1; or = 0
    if (Reg[rs]&0xFFFFFFFF) < (Reg[rt]&0xFFFFFFFF):
        Reg[rd] = 0x1
    else:
        Red[rd] = 0x0  

def sra(rd, rt, sa):
    # The contents of the low-order 32-bit word of GPR rt are shifted right, dumplicating the
    # sign-bit(bit 31)in the emptied bits; the word result is placed in GPR rd. The bit shift
    # count is specified by sa. If rd is a 64-bit register, the result word is sigh-extended
    Reg[rd] = Reg[rt] >> int(sa, 2)

def srav(rd, rt, rs):
    # The contents of the low-order 32-bit word of GPR rt are shifted right, dumplicating the
    # sign-bit(bit 31)in the emptied bits; the word result is placed in GPR rd. The bit shift
    # count is specified by the low-order five bits of GPR rs. If rd is a 64-bit register, the result word is sigh-extended
    Reg[rd] = Reg[rt] >> Reg[rs]

def srl(rd, rt, sa):
    # The contents of the low-order 32-bit word of GPR rt are shifted right, inserting 0s into
    # the emptied bits; the word result is placed in GPR rd. The bit shiftcount is specified by sa.
    #  If rd is a 64-bit register, the result word is sigh-extended
    Reg[rd] = int('0'*int(sa, 2) + ('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:])[0: 32 - int(sa,2)], 2)

def srlv(rd, rt, rs):
    # similar as srl, but bit shift count is specified by the low-order 5 bits of GPR rs
    sa = Reg[rs]
    Reg[rd] = int('0'*sa + ('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:])[0: 32 - sa], 2)

def sub(rd, rs, rt):
    # The 32-bit word value in GPR rt is substr from the 32-bit value in GPR rs to prouce a 32-bit
    # result. If it does not overflow, the 32-bit result is placed into GPR rd
    Reg[rd] = Reg[rs] - Reg[rt]

def subu(rd, rs, rt):
    # The 32-bit word value in GPR rt is substr from the 32-bit value in GPR rs to prouce a 32-bit
    # result. If it does not overflow, the 32-bit result is placed into GPR rd
    Reg[rd] = int('{:#035b}'.format(Reg[rs] - Reg[rt])[3:], 2) # take the lower 32 bits

def sw (rt, base, offset):
    if offset[0] ==  '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR = int('{:#035b}'.format(Reg[base] + EXTEND_offset)[3:], 2)
    Memory[ DATA_ADDR - Text_Start_Address     ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
    Memory[ DATA_ADDR - Text_Start_Address + 1 ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
    Memory[ DATA_ADDR - Text_Start_Address + 2 ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
    Memory[ DATA_ADDR - Text_Start_Address + 3 ] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)

def swl (rt, base, offset):
    if offset[0] ==  '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR_str = '{:#035b}'.format( Reg[base] + EXTEND_offset )[3:]
    DATA_ADDR_aligned = DATA_ADDR_str[:30] + '00'
    DATA_ADDR = int(DATA_ADDR_aligned, 2)

    if DATA_ADDR_str.endswith('00'):
        Memory[DATA_ADDR - Text_Start_Address] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)
    elif DATA_ADDR_str.endswith('01'):
        Memory[DATA_ADDR - Text_Start_Address] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
        Memory[DATA_ADDR - Text_Start_Address+1] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)
    elif DATA_ADDR_str.endswith('10'):
        Memory[DATA_ADDR - Text_Start_Address] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
        Memory[DATA_ADDR - Text_Start_Address+1] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
        Memory[DATA_ADDR - Text_Start_Address+2] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)
    elif DATA_ADDR_str.endswith('11'):
        Memory[ DATA_ADDR - Text_Start_Address] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
        Memory[ DATA_ADDR - Text_Start_Address+1] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
        Memory[ DATA_ADDR - Text_Start_Address+2] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
        Memory[ DATA_ADDR - Text_Start_Address+3] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)

def swr (rt, base, offset):
    if offset[0] ==  '1':
        offset += '1'*(32-len(offset))
    EXTEND_offset = int(offset, 2)
    DATA_ADDR_str = '{:#035b}'.format( Reg[base] + EXTEND_offset )[3:]
    DATA_ADDR_aligned = DATA_ADDR_str[:30] + '00'
    DATA_ADDR = int(DATA_ADDR_aligned, 2)

    data3 = '{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34]
    data2 = '{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26]
    data1 = '{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18]
    data0 = '{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10] 

    if DATA_ADDR_str.endswith('00'):
        Memory[ DATA_ADDR - 0x00400000] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
        Memory[ DATA_ADDR - 0x00400000 + 1] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
        Memory[ DATA_ADDR - 0x00400000 + 2] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
        Memory[ DATA_ADDR - 0x00400000 + 3] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[2:10], 2)
    elif DATA_ADDR_str.endswith('01'):
        Memory[ DATA_ADDR - 0x00400000 + 1] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
        Memory[ DATA_ADDR - 0x00400000 + 2] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
        Memory[ DATA_ADDR - 0x00400000 + 3] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[10:18], 2)
    elif DATA_ADDR_str.endswith('10'):
        Memory[ DATA_ADDR - 0x00400000 + 2] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)
        Memory[ DATA_ADDR - 0x00400000 + 3] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[18:26], 2)
    elif DATA_ADDR_str.endswith('11'):
        Memory[ DATA_ADDR - 0x00400000 + 3] = int('{:#034b}'.format(Reg[rt]&0xFFFFFFFF)[26:34], 2)

def xor(rd, rs, rt):
    # Combine the contents of GPR rs and GRP rt in a bitwise logical exclusive OR and place result in rd
    Reg[rd] = Reg[rs]^Reg[rt]

def xori(rt, rs, Imm):
    # Combine the contents of GPR rs and the 16-bit zero-extended imme in a bitwise logical 
    # exclusive OR operation and place the result into GPR rt
    if Imm[0] == '1':
        IMME_INT = int(Imm, 2) - int('1'*len(Imm), 2) - 1
    else:
        IMME_INT = int(Imm, 2)
    Reg[rt] = Reg[rs] ^ IMME_INT

def syscall ():
    syscall_code = Reg['00010']
    if   syscall_code == 1:
        print(Reg['00100'], end = '' )
        with open(OUTPUT_file, 'a') as out:
            out.write(str(Reg['00100']) )
    elif syscall_code == 4:
        DATA_ADDR = Reg['00100']
        while Memory[DATA_ADDR - 0x00400000] != 0:
            print(chr(Memory[ DATA_ADDR - 0x00400000] ), end = '' )
            with open(OUTPUT_file, 'a') as out:
                out.write(chr(Memory[DATA_ADDR - 0x00400000]))
            DATA_ADDR += 1
    elif syscall_code == 5:
        Reg['00010'] = int(input_text[Reg['input_idx'] ])
        Reg['input_idx'] += 1
    elif syscall_code == 8:
        Str = input_text[Reg['input_idx']]
        if len(Str) < Reg['00101']:
            for i in range(0, len(Str)):
                Memory[Reg['00100'] - 0x00400000+ i] = ord(Str[i])
            Memory[Reg['00100'] - 0x00500000 + len(Str)] = 0
        else:
            for i in range(Reg['00101']):
                Memory[Reg['00100'] - 0x00400000 + i] = ord(Str[i])
            Memory[Reg['00100'] - 0x00400000 + Reg['00101']] = 0
        Reg['input_idx'] += 1
    elif syscall_code == 9:
        Reg['00010'] = Reg['Virtual_DATA_ADDR']
        Reg['Virtual_DATA_ADDR'] += Reg['00100']
        if Reg['Virtual_DATA_ADDR'] % 4 == 1:
            Reg['Virtual_DATA_ADDR'] += 3
        elif Reg['Virtual_DATA_ADDR'] % 4 == 2:
            Reg['Virtual_DATA_ADDR'] += 2
        elif Reg['Virtual_DATA_ADDR'] % 4 == 1:
            Reg['Virtual_DATA_ADDR'] += 1
        else:
            Reg['Virtual_DATA_ADDR'] = Reg['Virtual_DATA_ADDR']
    elif syscall_code == 10 or syscall_code == 17:
        Reg['break'] = 1
    elif syscall_code == 11:
        print(chr(Reg['00100']), end = '' )
        with open(OUTPUT_file, 'a') as out:
            out.write( chr(Reg['00100']) )
    elif syscall_code == 12:
        Reg['00010'] = ord(input_text[Reg['input_idx'] ])
        Reg['input_idx'] += 1
    elif syscall_code == 13:
        file_name = ''
        file_name_addr = Reg['00100']
        while Memory[file_name_addr - 0x00400000] != 0:
            file_name += chr(Memory[ file_name_addr - 0x00400000])
            file_name_addr += 1
        # 以读写方式打开，并创建新的文件夹
        Reg['00100'] = os.open(file_name, os.O_RDWR | os.O_CREAT)
    elif syscall_code == 14:
        text_read = os.read(Reg['00100'], Reg['00110'])
        Reg['00100'] = Reg['00110']
        for i in range(0, len(text_read)):
            Memory[Reg['00101'] - 0x00400000 + i] = text_read[i]
    elif syscall_code == 15:
        text_write = b''
        for i in range(0, Reg['00110']):
            text2write += (Memory[Reg['00101'] - 0x00400000 + i]).to_bytes(1, 'big')
        Reg['00100'] = os.write(Reg['00100'], text_write)
    elif syscall_code == 16:
        os.close(Reg['00100'])


if __name__ == '__main__':
    x = 0
    while True:
        if x in indexes:
            Dump_Mem(x)
            Dump_Reg(x)
        x += 1
        instruction =  '{:#010b}'.format(Memory[Reg['pc']-0x00400000+3])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000+2])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000+1])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000])[2:]

        op = instruction[0: 6]
        rs = instruction[6:11]
        rt = instruction[11:16]
        rd = instruction[16:21]
        sa = instruction[21:26]
        Func = instruction[26:32]
        Imm_16 = instruction[16:32]
        Imm_26 = instruction[6:32]  

        # execute instruction
        if op == '000000':
            if Func == '100000':
                add(rd, rs, rt)
            elif Func == '100001':
                addu(rd, rs, rt)
            elif Func == '100100':
                and_R(rd, rs, rt)
            elif Func == '011010':
                div(rs, rt)
            elif Func == '011011':
                divu(rs, rt)
            elif Func == '001001':
                jalr(rs)
            elif Func == '001000':
                jr(rs)
            elif Func == '010000':
                mfhi(rd)
            elif Func == '010010':
                mflo(rd)
            elif Func == '010001':
                mthi(rs)
            elif Func == '010011':
                mtlo(rs)
            elif Func == '011000':
                mult(rs, rt)
            elif Func == '011001':
                multu(rs, rt)
            elif Func == '100111':
                nor(rd, rs, rt)
            elif Func == '100101':
                or_R(rd, rs, rt)
            elif Func == '000000':
                sll(rd, rt, sa)
            elif Func == '000100':
                sllv(rd, rt, rs)
            elif Func == '101010':
                slt(rd, rs, rt)
            elif Func == '101011':
                sltu(rd, rs, rt)           
            elif Func == '000011':
                sra(rd, rt, sa)
            elif Func == '000111':
                srav(rd, rt, rs)
            elif Func == '000010':
                srl(rd, rt, sa)
            elif Func == '000110':
                srlv(rd, rt, rs)
            elif Func == '100010':
                sub(rd, rs, rt)
            elif Func == '100011':
                subu(rd, rs, rt)
            elif Func == '001100':
                syscall()
            elif Func == '100110':
                xor(rd, rs, rt)
        elif op == '000001' and  rt == '00000':
            bltz(rs, Imm_16)                         
        elif op == '000001' and  rt == '00001':
            bgez(rs, Imm_16)
        elif op == '000010':
            j(Imm_26)
        elif op == '000011':
            jal(Imm_26)       
        elif op == '000100':
            beq(rs, rt, Imm_16)
        elif op == '000101':
            bne(rs, rt, Imm_16)
        elif op == '000110':
            blez(rs, Imm_16)
        elif op == '000111':
            bgez(rs, Imm_16)
        elif op == '001000':
            addi(rt, rs, Imm_16)
        elif op == '001001':
            addiu(rt, rs, Imm_16)
        elif op == '001010':
            slti(rt, rs, Imm_16)
        elif op == '001011':
            sltiu(rt, rs, Imm_16)
        elif op == '001100':
            andi(rt, rs, Imm_16)
        elif op == '001101':
            ori(rt, rs, Imm_16)
        elif op == '001110':
            xori(rt, rs, Imm_16)
        elif op == '001111':
            lui(rt, Imm_16)
        elif op == '100000':
            lb (rt, rs, Imm_16)
        elif op == '100001':
            lh(rt, rs, Imm_16)
        elif op == '100010':
            lwl(rt, rs, Imm_16)
        elif op == '100011':
            lw(rt, rs, Imm_16)
        elif op == '100100':
            lbu(rt, rs, Imm_16)
        elif op == '100101':
            lhu(rt, rs, Imm_16)
        elif op == '100110':
            lwr(rt, rs, Imm_16)
        elif op == '101000':
            sb(rt, rs, Imm_16)
        elif op == '101001':
            sh(rt, rs, Imm_16)
        elif op == '101010':
            swl(rt, rs, Imm_16)
        elif op == '101011':
            sw(rt, rs, Imm_16)
        elif op == '101110':
            swr(rt, rs, Imm_16)     
        Reg['pc'] += 4
        if Reg['break']: 
            break
