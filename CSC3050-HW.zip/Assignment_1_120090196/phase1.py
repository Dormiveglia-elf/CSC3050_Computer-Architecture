Start_Address = 0x400000 # default base address for an exetutable 

def firstScan(fileLine):
    i = 0
    while i < len(fileLine):                          # read each line                          
        fileLine[i] = fileLine[i].rstrip('\n')        # remove newline             
        fileLine[i] = fileLine[i].replace('\t', ' ')  # replace tab with space            
        fileLine[i] = fileLine[i].partition('#')      # search for the comments and split             
        fileLine[i] = fileLine[i][0]                  # remove comments if exiting              
        fileLine[i] = fileLine[i].partition(':')      # search for the label and split            
        fileLine[i] = [''.join(fileLine[i][:2]), fileLine[i][2]]
        i += 1
    # rearrange the testfile for convenience to read in phase2
    new_text = []
    for i in fileLine:                                 # extract list in old list(fileLine)
        for j in i:                                    # extract string in list
            new_text.append(j)                         # add the string to the new list
    for i in new_text:                                 # read the string one by one
        if i.isspace() == True:                        # to check whther the string is empty  
            new_text.remove(i)                         # remove it if empty
    new_text = [x for x in new_text if x != '']        # remove the string ''
    new_text = [x.strip() for x in new_text]           # remove the space at the beginning and
                                                       # end of the string

    for i in new_text:                                 # read string one by one
        if (i == '.data'):                             # check if the string is '.data'
            data_index = new_text.index('.data')       # if yes, record the index
            break                                      # break the for loop
        else:
            data_index = 0                             # if not, set the index 0
    text_index = new_text.index('.text')               # record the index of '.text' section

    final_text = []                                    # extract .text section as final list
    if data_index == 0:                                # .data at the beginning
        for i in range(text_index + 1, len(new_text)): # ignore the .data part
            final_text.append(new_text[i])             # add the .text part to the list
    else:                                              # .data part after the .text part
        for i in range(1, data_index):                 # read the .data part 
            final_text.append(new_text[i])             # add the .data part to the list

    for i in range(len(final_text)):                
        final_text[i] = ' '.join(final_text[i].split(',')) # remove comma between characters
        final_text[i] = ' '.join(final_text[i].split())    # remove tab

    for i in range(len(final_text)):
        if ':' not in final_text[i]:
            final_text[i] = final_text[i].split()          # split the characters in the instruction

    labelTable = {}                                        # creat the dictionary to store label and
    label_count = 0                                        # corresponding address
    PC = Start_Address                                     # start from 0x4000000
    for i in range(len(final_text)):
        if ':' not in final_text[i]:
            final_text[i].insert(0, hex(PC))               # insert the corresponding address at the begining
            PC += 4                                        # next address
        else:
            labelTable[final_text[i]] = hex(Start_Address + 4*(i - label_count)) # by formula
            label_count += 1

    return final_text, labelTable