import os
from phase1 import firstScan

R_op = '000000' # R-type opcode
N_A = '00000'   #N/A code

# list the R Type instructions
R_Type = ['add','addu', 'and', 'div', 'divu', 'jalr', 'jr', 'mfhi', 'mflo',
          'mthi', 'mtlo', 'mult', 'multu', 'nor', 'or', 'sll', 'sllv', 'slt',
          'sltu', 'sra', 'srav', 'srl', 'srlv', 'sub', 'subu', 'syscall', 'xor'
]
# list the I Type instructions
I_Type = ['addi', 'addiu', 'andi', 'beq', 'bgez', 'bgtz', 'blez', 'bltz',
          'bne', 'lb', 'lbu', 'lh', 'lhu', 'lui', 'lw', 'ori', 'sb', 'slti',
          'sltiu', 'sh', 'sw', 'xori', 'lwl', 'lwr', 'swl', 'swr'
]
# list the J Type instructions
J_Type = ['j', 'jal'
]
# R-type: function code, I,J-type: opcode
instr_code ={'add': '100000', 'addu': '100001', 'and': '100100', 'div': '011010',
             'divu': '011011', 'jalr': '001001', 'jr': '001000', 'mfhi': '010000',
             'mflo': '010010', 'mthi': '010001', 'mtlo': '010011', 'mult': '011000',
             'multu': '011001', 'nor': '100111', 'or': '100101', 'sll': '000000',
             'sllv': '000100', 'slt': '101010', 'sltu': '101011', 'sra': '000011',
             'srav': '000111', 'srl': '000010', 'srlv': '000110', 'sub': '100010',
             'subu': '100011', 'syscall': '001100', 'xor': '100110', 'addi': '001000',
             'addiu': '001001', 'andi': '001100', 'beq': '000100', 'bgez': '000001',
             'bgtz': '000111', 'blez': '000110', 'bltz': '000001', 'bne': '000101',
             'lb': '100000', 'lbu': '100100', 'lh': '100001', 'lhu': '100101',
             'lui': '001111', 'lw': '100011', 'ori': '001101', 'sb': '101000', 
             'slti': '001010', 'sltiu': '001011', 'sh': '101001', 'sw': '101011',
             'xori': '001110', 'lwl': '100010', 'lwr': '100110', 'swl': '101010',
             'swr': '101110', 'j': '000010', 'jal': '000011'
}
# register name and corresponding machine code
regs = {
    '$zero' : '00000',     # r0
    '$at'   : '00001',     # r1
    '$v0'   : '00010',     # r2
    '$v1'   : '00011',     # r3
    '$a0'   : '00100',     # r4
    '$a1'   : '00101',     # r5
    '$a2'   : '00110',     # r6
    '$a3'   : '00111',     # r7
    '$t0'   : '01000',     # r8
    '$t1'   : '01001',     # r9
    '$t2'   : '01010',     # r10
    '$t3'   : '01011',     # r11
    '$t4'   : '01100',     # r12
    '$t5'   : '01101',     # r13
    '$t6'   : '01110',     # r14
    '$t7'   : '01111',     # r15
    '$s0'   : '10000',     # r16
    '$s1'   : '10001',     # r17
    '$s2'   : '10010',     # r18
    '$s3'   : '10011',     # r19
    '$s4'   : '10100',     # r20
    '$s5'   : '10101',     # r21
    '$s6'   : '10110',     # r22
    '$s7'   : '10111',     # r23
    '$t8'   : '11000',     # r24
    '$t9'   : '11001',     # r25
    '$k0'   : '11010',     # r26
    '$k1'   : '11011',     # r27
    '$gp'   : '11100',     # r28
    '$sp'   : '11101',     # r29
    '$fp'   : '11110',     # r30
    '$ra'   : '11111'      # r31
}
print() # easy for user to input clearly
test_file = input("Please ensure the test file name again(must same as above):")
while not os.path.exists(test_file):
    test_file=input("Your input is wrong, please enter the correct name:")

with open((test_file), 'r') as file_in:
    text_line = file_in.readlines()
final_text, labelTable = firstScan(text_line)

Type_1 = ['and', 'add', 'addu', 'nor', 'or', 'slt', 'sltu', 'sub', 'subu', 'xor']  #rd, rs, rt
Type_2 = ['div', 'divu', 'mult', 'multu'] # rs, rt
Type_3 = ['jr', 'mthi', 'mtlo'] # rs
Type_4 = ['sll', 'sra', 'srl']  # rd, rt, sa 
Type_5 = ['sllv', 'srav', 'srlv'] # rd, rt, rs
Type_6 = ['mfhi', 'mflo']  # rd
Type_7 = ['jalr']   #rd, rs
Type_8 = ['syscall'] # none
def R_Code(instruction):    # R-type --> machine code
    if instruction[1] in Type_1:
        Rcode = R_op + regs[instruction[3]] + regs[instruction[4]] + regs[instruction[2]] + N_A + instr_code.get(instruction[1])
    elif instruction[1] in Type_2:
        Rcode = R_op + regs[instruction[2]] + regs[instruction[3]] + N_A + N_A + instr_code.get(insr[1])
    elif instruction[1] in Type_3:
        Rcode = R_op + regs[instruction[2]] + N_A + N_A + N_A + instr_code.get(instruction[1])
    elif instruction[1] in Type_4:
        shift_count = int(instruction[4])
        if shift_count < 0:
            shift_count_str = bin(-shift_count).replace('0b', '')
            shift_count_str = shift_count_str.rjust(5, '0')
            # a method to do the 2's complement
            index_1 = shift_count_str.rfind('1')
            s1 = list(shift_count_str)
            for i in range(index_1):
                if s1[i] == '1': s1[i] ='0'
                else: s1[i] = '1'
            shift_count_str = ''.join(s1)
        else:
            shift_count_str = bin(shift_count).replace('0b', '')
            shift_count_str = shift_count_str.rjust(5, '0')
        Rcode = R_op + N_A + regs[instruction[3]] + regs[instruction[2]] + shift_count_str + instr_code.get(instruction[1])
    elif instruction[1] in Type_5:
        Rcode = R_op + regs[instruction[4]] + regs[instruction[3]] + regs[instruction[2]] + N_A + instr_code.get(instruction[1])
    elif instruction[1] in Type_6:
        Rcode = R_op + N_A + regs[instruction[2]] + N_A + N_A + instr_code.get(instruction[1])
    elif instruction[1] in Type_7:
        Rcode = R_op + regs[instruction[2]] + N_A + regs[instruction[3]] + N_A + instr_code.get(instruction[1])
    elif instruction[1] in Type_8:
        Rcode = R_op + N_A + N_A + N_A + N_A + instr_code.get(insr[1])
    return Rcode

Type_9  = ['lb', 'lbu', 'lh', 'lhu', 'lw', 'sh', 'sw', 'sb', 'lwl', 'lwr', 'swl', 'swr'] # rt, immediate(rs)
Type_10 = ['addi', 'addiu', 'andi', 'ori', 'slti', 'sltiu', 'xori'] # rt, rs, immediate
Type_11 = ['bgtz', 'blez', 'bltz'] # rs, label, rt = 00000
Type_12 = ['beq', 'bne'] # rs, rt, label
Type_13 = ['bgez'] # rs, label, rt = 00001
Type_14 = ['lui'] # rt, immediate
def I_imme_trans(immediate):  # translate the immediate to 16 bits binary string
    if   '0x' in immediate:
        immediate = int(immediate, 16)
    elif '0o' in immediate:
        immediate = int(immediate, 8)
    elif '0b' in immediate:
        immediate = int(immediate, 2)
    else:
        immediate = int(immediate)
    # 2's complement
    if immediate < 0:
        immediate = int('0xffff', 16) + int(immediate) + 1
    imm_str = bin(immediate).replace('0b', '')
    imm_str = imm_str.rjust(16, '0')
    return imm_str   

def I_lw_sw(subpart):  # separate the register and immediate
    subpart = subpart.split('(')
    imm = subpart[0]
    register = subpart[1].rstrip(')')
    return imm, register

def I_Code(instruction): # I-type --> machine code
    if instruction[1] in Type_9:
        Icode = instr_code.get(instruction[1]) + regs[I_lw_sw(instruction[3])[1]] + regs[instruction[2]]  + I_imme_trans(I_lw_sw(instruction[3])[0])
    elif instruction[1] in Type_10:
        Icode = instr_code.get(instruction[1]) + regs[instruction[3]] + regs[instruction[2]] + I_imme_trans(instruction[4])
    elif instruction[1] in Type_11:
        pc = int(instruction[0], 16)
        label_addr = int(labelTable.get(instruction[3]+':'), 16)
        immediate = hex(int((label_addr - pc - 4)/4))
        Icode = instr_code.get(instruction[1]) + regs[instruction[2]] + N_A + I_imme_trans(immediate)
    elif instruction[1] in Type_12:
        pc = int(instruction[0], 16)
        label_addr = int(labelTable.get(instruction[4]+':'), 16)
        immediate = hex(int((label_addr - pc - 4)/4))
        Icode = instr_code.get(instruction[1]) + regs[instruction[2]] + regs[instruction[3]] + I_imme_trans(immediate)
    elif instruction[1] in Type_13:
        pc = int(instruction[0], 16)
        label_addr = int(labelTable.get(instruction[3]+':'), 16)
        immediate = hex(int((label_addr - pc - 4)/4))
        Icode = instr_code.get(instruction[1]) + regs[instruction[2]] + '00001' + I_imme_trans(immediate)
    elif instruction[1] in Type_14:
        Icode = instr_code.get(instruction[1]) + N_A + regs[instruction[2]] + I_imme_trans(instruction[3])
    return Icode

Type_15 = ['j', 'jal'] # label
def J_Code(instruction): # J-type --> machine code
    if instruction[1] in ['j', 'jal']:
        Jum_ADDR  = int(labelTable.get(instruction[2]+':'), 16)/4
        Jcode = instr_code.get(instruction[1]) + str(format(int(Jum_ADDR), '026b'))
    return Jcode
 
def MipsToMachineCode(): # second scan, generade the machine code of the whole file
    Machine_code = []
    for i in range(len(final_text)):
        if ':' not in final_text[i]:
            if final_text[i][1] in R_Type:
                Machine_code.append(R_Code(final_text[i]))
            elif final_text[i][1] in I_Type:
                Machine_code.append(I_Code(final_text[i]))
            elif final_text[i][1] in J_Type:
                Machine_code.append(J_Code(final_text[i]))
            else: print(final_text[i][1], ': This instruction is not supported in this assembler.')
    return Machine_code

Code_list = MipsToMachineCode()
output_file = input("Please ensure the output file name again(must same as above): ")
with open(output_file, 'w') as file_out:
    for i in range(len(Code_list)):
        file_out.write(Code_list[i] + '\n')